/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.samples.linkedin.jsf.bean;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;


@Named("sampleAppScopedBean")
@ApplicationScoped
public class SampleApplicationScopedBean {
    
}
