/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jsfassignment;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

/**
 *
 * @author 0063190S
 */

@Named("converterBean")
@RequestScoped
public class ConverterBean {
    
    int optionChosen;
    
    private String inputText;
    private String outputText;
    
    private double inputValue;
    private double outputValue;

    public ConverterBean() {
    }
    
    
    public void convert()
    {
        inputValue = Double.parseDouble(inputText);
        
        // Pounds to Kilos
        if (optionChosen == 1)
        {
           outputValue = inputValue * 0.453591;
           outputText = Double.toString(outputValue);
        }
        
        // Kilos to Pounds
        if (optionChosen == 2)
        {
           outputValue = inputValue / 0.453591;
           outputText = Double.toString(outputValue);
        }
    }

    public String getInputText() {
        return inputText;
    }

    public void setInputText(String inputText) {
        this.inputText = inputText;
    }

    public String getOutputText() {
        return outputText;
    }

    public void setOutputText(String outputText) {
        this.outputText = outputText;
    }

    public double getInputValue() {
        return inputValue;
    }

    public void setInputValue(double inputValue) {
        this.inputValue = inputValue;
    }

    public double getOutputValue() {
        return outputValue;
    }

    public void setOutputValue(double outputValue) {
        this.outputValue = outputValue;
    }

    public int getOptionChosen() {
        return optionChosen;
    }

    public void setOptionChosen(int optionChosen) {
        this.optionChosen = optionChosen;
    }
    
    
}
