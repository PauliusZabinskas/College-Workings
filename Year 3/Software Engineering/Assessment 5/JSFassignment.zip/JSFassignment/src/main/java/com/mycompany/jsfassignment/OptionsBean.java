/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jsfassignment;

import java.util.LinkedList;
import java.util.List;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 *
 * @author 0063190S
 */
@ApplicationScoped
@Named("optionsBean")

public class OptionsBean {

    private List<Option> options;
    
    public OptionsBean() {
    }

    
    @PostConstruct
    public void loadOptions() {
        
        options = new LinkedList();
        
        Option o1 = new Option("Pounds to Kilos", 1);
        Option o2 = new Option("Kilos to Pounds", 2);
        
        options.add(o1);
        options.add(o2);

        System.out.println("Conversion options loaded");
    }

    public List<Option> getOptions() {
        return options;
    }

    public void setOptions(List<Option> options) {
        this.options = options;
    }

  
    
    

}
