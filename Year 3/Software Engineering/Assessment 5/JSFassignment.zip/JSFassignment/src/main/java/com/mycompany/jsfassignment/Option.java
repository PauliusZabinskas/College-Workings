/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.jsfassignment;

import java.io.Serializable;

/**
 *
 * @author 0063190S
 */
public class Option implements Serializable 
{
    
    private String optionValue;
    private int optionID;

    public Option(String optionValue, int optionID) {
        this.optionValue = optionValue;
        this.optionID = optionID;
    }

    public String getOptionValue() {
        return optionValue;
    }

    public void setOptionValue(String optionValue) {
        this.optionValue = optionValue;
    }

    public int getOptionID() {
        return optionID;
    }

    public void setOptionID(int optionID) {
        this.optionID = optionID;
    }
    
    
    
    
}
