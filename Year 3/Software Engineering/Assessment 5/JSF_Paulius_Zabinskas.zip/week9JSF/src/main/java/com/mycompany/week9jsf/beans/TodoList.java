/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.week9jsf.beans;

import com.mycompany.week9jsf.data.Todo;
import com.mycompany.week9jsf.services.TodoFacade;
import java.util.List;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;

import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;

import jakarta.inject.Named;
import java.io.Serializable;

/**
 *
 * @author 0063190S
 */
@Named("todoListBean")
@RequestScoped
public class TodoList implements Serializable
{

    @EJB
    private TodoFacade todoFacade;

    private List<Todo> todosList;
    
    @PostConstruct
    public void postConstruct()
    {
        System.out.println("calling todo facade");
        todosList = todoFacade.findAll();
        System.out.println("num todos = " + todosList.size());
    }
    
       public List<Todo> getTodosList() {
           System.out.println("calling getTodosList");
        return todosList;
    }
}
