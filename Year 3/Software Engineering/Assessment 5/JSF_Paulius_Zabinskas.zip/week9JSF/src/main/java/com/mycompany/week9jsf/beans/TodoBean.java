/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.week9jsf.beans;

import com.mycompany.week9jsf.data.Todo;
import com.mycompany.week9jsf.services.TodoFacade;
import jakarta.annotation.PostConstruct;
import jakarta.ejb.EJB;
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;

/**
 *
 * @author 0063190S
 */
@Named("todoBean")
@RequestScoped
public class TodoBean {
    
    @EJB
    private TodoFacade todoFacade;
    
    private String category;
    private String description;  // Added field
    private Integer priority;    // Changed to Integer to handle null
    private long id;
    private Todo todo;
    
    @PostConstruct
    public void postConstruct() {
        String todoIdParam = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("todoId");
        if (todoIdParam != null && !todoIdParam.isEmpty()) {
            id = Long.parseLong(todoIdParam);
            todo = todoFacade.find(id);
            if (todo != null) {  // Added null check
                category = todo.getCategory();
                description = todo.getDescription();  // Load description
                priority = todo.getPriority();        // Load priority
            }
        } else {
            todo = new Todo(); // Initialize todo to avoid NullPointerException
        }
    }
    
    public String getCategory() {
        return category;
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getPriority() {
        return priority;
    }

    public void setPriority(Integer priority) {
        this.priority = priority;
    }
    
    public long getId() {
        return id;
    }
    
    public void setId(long id) {
        this.id = id;
    }
    
    public String add() {
        // New Todo should be initialized at the start of the method to avoid overwriting the existing todo
        Todo newTodo = new Todo();
        newTodo.setCategory(category);
        newTodo.setDescription(description); // Set description
        newTodo.setPriority(priority);       // Set priority
        todoFacade.create(newTodo);
        return "success"; // Navigate to the success page or appropriate outcome
    }

    public String update() {
        todo.setCategory(category);
        todo.setDescription(description);
        todo.setPriority(priority);
        todoFacade.edit(todo);
        return "success";
    }
    
    public String delete() {
        todoFacade.remove(todo);
        return "success";
    }
}
