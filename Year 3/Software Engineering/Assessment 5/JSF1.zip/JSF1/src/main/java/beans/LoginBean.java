/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSF/JSFManagedBean.java to edit this template
 */
package beans;

import jakarta.inject.Named;
import jakarta.enterprise.context.RequestScoped;

/**
 *
 * @author o_molloy
 */
@Named(value = "loginBean")
@RequestScoped
public class LoginBean {

    private String userName;
    private String password;
    private String errorMsg;

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }
    
        /**
     * Creates a new instance of LoginBean
     */
    public LoginBean() {
    }
    
    
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String validate()
    {
        if (userName.equals("admin") && password.equals("admin"))
        {
            errorMsg = null;
            return "welcome";
        }
        else
        {
            errorMsg = "Invalid user name or password - please try again";
            return null;
        }
    }
    
}
