// User defined Exception

public class LessThanZero extends Exception {

  public LessThanZero(String message) {
    super(message);
  }
}
