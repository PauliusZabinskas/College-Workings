// This is the Client ...

import java.io.*;
import java.net.*;

class TCPClient {

  public static void main(String args[]) throws 		IOException {
    Socket sock;

    // Open our connection to dcham, at port 4444
    // If you try this on your system, insert your system
    // in place of "dcham" - "dcham.nuigalway.ie" is my
    // system name.

    String server = "localhost";
    if (args.length > 0)
      server = args[0];

    sock = new Socket(server,4444);

    // Get I/O streams from the socket
    // DataInputStream readLine() method has been deprecated so use BufferedReader instead
    BufferedReader in
        = new BufferedReader(new InputStreamReader(sock.getInputStream()));
    PrintStream out = new PrintStream(sock.getOutputStream() );

    String fromServer = in.readLine();

    System.out.println("Got this from server:" + 		fromServer);
    // assume that we expected the question, so
    // just go ahead and answer

    out.println("I would bark !");
    out.flush();

    sock.close();
  }
}
