// Handles the server interaction with a connected client
// The data exchange is exactly the same as previously

import java.io.*;
import java.net.*;

class TCPClientHandler extends Thread {
  private Socket sock;

  public TCPClientHandler(Socket sock) {
    this.sock = sock;
  }

  // This is what the thread runs when started...
  public void run() {
    try {
      String query = "If you met me would you say hello, or bark ?";

      // Get I/O streams from the socket
      PrintStream out = new PrintStream(sock.getOutputStream());

      // DataInputStream readLine() method has been deprecated so use BufferedReader instead
      BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));

      // Send our query
      out.println(query);
      out.flush();

      // get the reply
      String reply = in.readLine();
      if (reply.indexOf("bark") > -1)
      System.out.println("On the Internet I know this is a DOG!");
      else System.out.println("Probably a person or an AI experiment");
      // Close this connection, (not the overall server socket)
      sock.close();
    }
    catch (IOException ex)
    {
      System.out.println("Some error occured!");
      ex.printStackTrace();
    }
  }
}
