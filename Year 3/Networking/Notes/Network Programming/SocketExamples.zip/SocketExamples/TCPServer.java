//  Network server that detects the presence of
//  dogs on the Internet !

import java.io.*;
import java.net.*;

class TCPServer {
  public static void main(String a[]) throws IOException {
    int backlog = 10;  // Max queue size for pending connections
    int port = 4444;   // TCP port number to use for incoming connections
    Socket sock;

    String query = "If you met me would you say hello, or bark ?";

    // Create a ServerSocket that binds to all available IP addresses on this device
    ServerSocket servsock = new ServerSocket(port, backlog);

    while (true) {
      // wait for the next client connection
      sock=servsock.accept();

      // Get I/O streams from the socket
      PrintStream out = new PrintStream(sock.getOutputStream());

      // DataInputStream readLine() method has been deprecated so use BufferedReader instead
      BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));

      // Send our query
      out.println(query);
      out.flush();

      // get the reply
      String reply = in.readLine();
      if (reply.indexOf("bark") > -1)
         System.out.println("On the Internet I know this is a DOG!");
      else System.out.println("Probably a person or an AI experiment");

      // Close this connection, (not the overall 		// server socket)
      sock.close();
    }
  }
}

// However, no one knows you're a dog...
// unless you tell them (we need a client) !
