
// Set up a Server that will receive UDP packets from a
// client and then send UDP packets to a client

import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;

// Java extension packages
import javax.swing.*;

public class UDPServer extends JFrame {
  private JTextArea displayArea;
  private DatagramPacket sendPacket, receivePacket;
  private DatagramSocket socket;

  // set up GUI and DatagramSocket
  public UDPServer()
  {
    super( "UDPServer" );

    displayArea = new JTextArea();
    getContentPane().add( new JScrollPane( displayArea ),
    BorderLayout.CENTER );
    setSize( 400, 300 );
    setVisible( true );

    // create DatagramSocket for sending and receiving packets
    try {
      socket = new DatagramSocket( 5000 );
    }

    // process problems creating DatagramSocket
    catch( SocketException socketException ) {
      socketException.printStackTrace();
      System.exit( 1 );
    }

  }  // end Server constructor

  // wait for packets to arrive, then display data and echo
  // packet to client
  public void waitForPackets()
  {
    // loop forever
    while ( true ) {

      // receive packet, display contents, echo to client
      try {

        // set up packet
        byte data[] = new byte[ 100 ];
        receivePacket =
        new DatagramPacket( data, data.length );

        // wait for packet
        socket.receive( receivePacket );

        // process packet
        displayPacket();

        // echo information from packet back to client
        sendPacketToClient();
      }

      // process problems manipulating packet
      catch( IOException ioException ) {
        displayArea.append( ioException.toString() + "\n" );
        ioException.printStackTrace();
      }

    }  // end while

  }  // end method waitForPackets

  // display packet contents
  private void displayPacket()
  {
    displayArea.append( "\nPacket received:" +
    "\nFrom host: " + receivePacket.getAddress() +
    "\nHost port: " + receivePacket.getPort() +
    "\nLength: " + receivePacket.getLength() +
    "\nContaining:\n\t" +
    new String( receivePacket.getData(), 0,
    receivePacket.getLength() ) );
  }

  // echo packet to client
  private void sendPacketToClient() throws IOException
  {
    displayArea.append( "\n\nEcho data to client..." );

    // create packet to send
    sendPacket = new DatagramPacket( receivePacket.getData(),
    receivePacket.getLength(), receivePacket.getAddress(),
    receivePacket.getPort() );

    // send packet
    socket.send( sendPacket );

    displayArea.append( "Packet sent\n" );
    displayArea.setCaretPosition(
    displayArea.getText().length() );
  }

  // execute application
  public static void main( String args[] )
  {
    UDPServer application = new UDPServer();

    application.setDefaultCloseOperation(
    JFrame.EXIT_ON_CLOSE );

    application.waitForPackets();
  }
}  // end class UDPServer
