package org.example;

import java.io.Serializable;

/**
 * Student Name: Paulius Zabinskas
 * Student ID: 20120267
 */
public enum Country implements Serializable {
    GERMANY,
    FRANCE,
    SPAIN,
    ITALY,
    NETHERLANDS,
    BELGIUM,
    AUSTRIA,
    PORTUGAL,
    SWEDEN,
    POLAND;
}
