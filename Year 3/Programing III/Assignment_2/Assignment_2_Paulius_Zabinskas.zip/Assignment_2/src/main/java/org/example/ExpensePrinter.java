package org.example;

/**
 * Name: Paulius Zabinskas
 * Id: 2012067
 *
 */

import java.util.List;
// Contract to be used
public interface ExpensePrinter {

    void print(List<Expense> printer);


}
