package org.example;
/**
 * Name: Paulius Zabinskas
 * Id: 2012067
 *
 */
public enum Category {
    TRAVEL_AND_SUBSISTENCE,
    SUPPLIES,
    ENTERTAINMENT,
    EQUIPMENT,
    OTHER

}
