<template>
<router-link to="/">Home</router-link>
<router-link to="/blog">Blog</router-link>
</template>


<style scoped>

</style>