public interface MethodsClass {

    public boolean Method(String input);
    public int get_oCount();
    public int getNCount();
}
